//
// Don't forget to update the version number in Ctp.rgs, AxCtp.inf, NpCtp.js
//

#define VER_COMPANY				"American Greetings.com\0"
#define VER_COPYRIGHT			"Copyright � 1999 American Greetings.com\0"

#define	VER_PRODUCT_VERSION		1,0,0,0
#define	VER_PRODUCT_VERSION_STR	"1.0"
#define	VER_FILE_VERSION		1,0,0,0
#define	VER_FILE_VERSION_STR	"1.0"
