//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NPCTP.rc
//
#define IDD_CTLPANEL                    102
#define IDD_WAITDLG                     103
#define IDC_PAGE1                       201
#define IDR_AGLOGO                      201
#define IDC_PAGE2                       202
#define IDR_CPLOGO                      202
#define IDC_PAGE3                       203
#define IDR_CACFC                       203
#define IDC_PAGE4                       204
#define IDD_DBLSIDEINTRO                204
#define IDC_FONT                        205
#define IDD_DBLSIDESTEP1                205
#define IDC_PTSIZE                      206
#define IDD_DBLSIDEEND                  206
#define IDC_COLOR                       207
#define IDD_DBLSIDESTEP2                207
#define IDC_LEFT                        208
#define IDB_1UP                         208
#define IDC_CENTER                      209
#define IDB_2UP                         209
#define IDC_RIGHT                       210
#define IDB_3UP                         210
#define IDC_PRINT                       211
#define IDB_2DOWN                       211
#define IDC_SINGLEFOLD                  212
#define IDB_1UP2DOWN                    212
#define IDC_QUARTERFOLD                 213
#define IDC_FRAME1                      214
#define IDC_FRAME2                      215
#define IDC_FRAME3                      216
#define IDC_FRAME4                      217
#define IDC_DBLSIDE                     218

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         219
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
